//keys to open doors


let playerX = 50;
let playerY = 50;
let playerRadius = 12.5;
let playerSpeed = 3;

let keyX = 175;
let keyY = 175;

let keyFollowing = false;

let img2;


let img;
function preload(){
  img = loadImage('key.png');
    img2 = loadImage('character.png')

}

function setup() {
  createCanvas(570,470);
}

function draw(){
     background(100);
  
  if(keyIsDown(LEFT_ARROW) == true) {
   playerX = playerX - playerSpeed;
  }
  
  if(keyIsDown(RIGHT_ARROW) == true) {
   playerX = playerX + playerSpeed;
  }
  
  if(keyIsDown(UP_ARROW) == true) {
   playerY = playerY - playerSpeed;
  }
  
  if(keyIsDown(DOWN_ARROW) == true) {
   playerY = playerY + playerSpeed;
    }
  
  fill('blue')
  image(img2,playerX,playerY,400,400);
  
  fill('yellow');
  if(keyFollowing) {
    image(img, playerX - 50, playerY, 400, 400)
  } else {
    image(img,keyX,keyY,400,400);
  }
  
  
  if(playerX >= keyX - 25 && playerX <= keyX + 25 && playerY >= keyY - 25 && playerY <= keyY + 25) {
    keyFollowing = true;
  }

}
    
 
          
    
      
  
  //let randomNumber = Math.random();
  
  //if(randomNumber > 0.5) {
    
  //randomNumber = Math.random();



  








